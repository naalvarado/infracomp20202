
public class Mensaje {
	
	private int contenido;
	
	public Mensaje(int cont) {
		this.contenido = cont;
	}

	public int getContenido() {
		return contenido;
	}

	public void setContenido(int contenido) {
		this.contenido = contenido;
	}
	
}
