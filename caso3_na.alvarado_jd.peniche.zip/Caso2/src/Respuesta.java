
public class Respuesta {
	private boolean termino;
	
	public Respuesta() {
		termino = false;
	}
	
	public boolean getTer() {
		return termino;
	}
	
	public void ternimo() {
		termino = true;
	}
}
